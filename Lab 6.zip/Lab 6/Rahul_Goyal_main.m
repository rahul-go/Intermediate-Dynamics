%% Rahul_Goyal_main Usage and Description
% ME 326 Winter 2018 - Laboratory Assignment #6
%
% *Author:* RAHUL GOYAL
%
% California Polytechnic State University, San Luis Obispo, CA
%
% *Date Created:* March 06, 2018
%
% *Date Modified:* March 13, 2018
%
% *Description:*
% TODO
% 
% *Required Files:*
%
% * TODO
%
% *Still To Do:*
%
% * Start!



%% Problem Statement
% TODO



%% Reset
% The following was used while debugging.

close all;
clear all;
clc;



%% Given Values
% The following assigns values given by the problem statement to variables.

% Given Values
r_1 = 2;                        % TODO
r_2 = 3;                        % TODO
r_3 = 7;                        % TODO
r_4 = 8;                        % TODO
tdot_2 = 1;                     % TODO
t2_f = -4*pi;                   % TODO (rad)



%% Initial Conditions
% The following sets the initial conditions of the slider-crank.

% TODO
t2_0 = deg2rad(30);             % Angular position of TODO (rad)

% Position Initial Conditions
t3_0 = 0.1;
t4_0 = 0.1;
minimize = @(test_x) MyPosIC(t2_0, test_x);
x_0 = fminsearch(minimize, [t3_0, t4_0]);

% Easy access to...
t3_0 = x_0(1);                  % TODO
t4_0 = x_0(2);                  % TODO

% Velocity Initial Conditions
c2_0 = cos(t2_0);
s2_0 = sin(t2_0);
c3_0 = cos(t3_0);
s3_0 = sin(t3_0);
c4_0 = cos(t4_0);
s4_0 = sin(t4_0);

A = [(-r_3*s3_0) (r_4*s4_0)
     (r_3*c3_0) (-r_4*c4_0)]
 
B = [(r_2*s2_0*tdot_2)
     (-r_2*c2_0*tdot_2)]
 
x = A\B;

tdot3_0 = x(1)
tdot4_0 = x(2)
v_0 = [tdot3_0, tdot4_0];



%% Simulate the Crank-Rocker Using Simulink
% TODO
sim('Simulator.slx');



%% Simulation Animation
% The following animates the crank-rocker by using the simulation data.

% Cartesian Coordinates of Vector R1
r1_x = [0, r_1];
r1_y = [0, 0];

% Easy access to...
t_3 = xout(:, 1);               % Angular position of link 3 (rad)
t_4 = xout(:, 2);               % Angular position of link 4 (rad)